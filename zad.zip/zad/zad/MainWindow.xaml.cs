﻿using System.Security;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace zad
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ToggleButton_Checked(object sender, RoutedEventArgs e)
        {
            descriptionPopup.IsOpen = true;
            toggleButton.Content = "Ukryj opis";
        }

        private void ToggleButton_Unchecked(object sender, RoutedEventArgs e)
        {
            descriptionPopup.IsOpen = false;
            toggleButton.Content = "Pokaż opis";
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            textBlockInFirstPanel.Text = textBox.Text;
        }
        private bool colorChanged = false;

        private bool colorChangedTextBox1 = false;
        private bool colorChangedTextBox2 = false;
        private bool colorChangedTextBox3 = false;

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = (TextBox)sender;
            
            if (textBox == textBox1 && !colorChangedTextBox1)
            {
                textBox.Foreground = new SolidColorBrush(Colors.Red);
                colorChangedTextBox1 = true;
            }
            else if (textBox == textBox2 && !colorChangedTextBox2)
            {
                textBox.Foreground = new SolidColorBrush(Colors.Red);
                colorChangedTextBox2 = true;
            }
            else if (textBox == textBox3 && !colorChangedTextBox3)
            {
                textBox.Foreground = new SolidColorBrush(Colors.Red);
                colorChangedTextBox3 = true;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = (TextBox)sender;
            textBox.FontStyle = FontStyles.Normal;
            if (textBox == textBox1)
            {
                textBox.Foreground = new SolidColorBrush(Colors.Blue);
            }
            else if (textBox == textBox2)
            {
                textBox.Foreground = new SolidColorBrush(Colors.Blue);
            }
            else if (textBox == textBox3)
            {
                textBox.Foreground = new SolidColorBrush(Colors.Blue);
            }
        }
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton radioButton)
            {
                if (radioButton.Content.ToString() == "Inna odpowiedź")
                {
                    otherAnswerTextBox.Visibility = Visibility.Visible;
                }
                else
                {
                    otherAnswerTextBox.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void TextBlock_MouseEnter(object sender, MouseEventArgs e)
        {
            var textBlock = (TextBlock)sender;
            var border = (Border)textBlock.Parent;
            border.BorderBrush = Brushes.DarkCyan;
            border.Background = new SolidColorBrush(Color.FromArgb(77, 173, 216, 230));

        }

        private void TextBlock_MouseLeave(object sender, MouseEventArgs e)
        {
            var textBlock = (TextBlock)sender;
            var border = (Border)textBlock.Parent;
            border.BorderBrush = Brushes.Transparent; 
            border.Background = new SolidColorBrush(Colors.Transparent);
        }

        private TextBlock lastClickedTextBlock;

        private void TextBlock_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var textBlock = (TextBlock)sender;

            if (lastClickedTextBlock != null)
            {
                lastClickedTextBlock.Foreground = Brushes.Black; 
            }

            lastClickedTextBlock = textBlock;
            textBlock.Foreground = Brushes.LightBlue; 
        }


        private void ComboBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            endTextBlock.Text = comboBox.Text;
        }




    }
}
